Algoritmo AnioBisiesto
    // Definici�n de la variable correspondiente como n�mero entero
    Definir anio Como Entero;
    
    // Entrada de datos del usuario
    Escribir "A�o:";
    Leer anio;
    
    // Condicional aplicando la regla exacta: divisible por 400 O (divisible por 4 Y NO por 100)
    Si (anio MOD 400 == 0) O (anio MOD 4 == 0 Y anio MOD 100 <> 0) Entonces
        Escribir "Resultado: A�O BISIESTO";
    Sino
        Escribir "Resultado: NO BISIESTO";
    FinSi
FinAlgoritmo