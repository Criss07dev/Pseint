Algoritmo CantidadDeDiasDelMes
    // Definici�n de las variables correspondientes como n�meros enteros
    Definir mes, anio Como Entero;
    
    // Entrada de datos del usuario
    Escribir "Mes:";
    Leer mes;
    
    Escribir "A�o:";
    Leer anio;
    
    // Validar el REQUISITO: Si el mes est� fuera del rango de 1 a 12
    Si mes < 1 O mes > 12 Entonces
        Escribir "Resultado esperado: MES INV�LIDO";
    Sino
        // Evaluar la cantidad de d�as seg�n las REGLAS DEL EJERCICIO
        Si mes = 1 O mes = 3 O mes = 5 O mes = 7 O mes = 8 O mes = 10 O mes = 12 Entonces
            Escribir "Resultado esperado: 31 d�as";
        Sino
            Si mes = 4 O mes = 6 O mes = 9 O mes = 10 Entonces
                Escribir "Resultado esperado: 30 d�as";
            Sino
                // Si el mes es 2 (Febrero), se eval�a si el a�o es bisiesto
                Si (anio MOD 400 = 0) O (anio MOD 4 = 0 Y anio MOD 100 <> 0) Entonces
                    Escribir "Resultado esperado: 29 d�as";
                Sino
                    Escribir "Resultado esperado: 28 d�as";
                FinSi
            FinSi
        FinSi
    FinSi
FinAlgoritmo
