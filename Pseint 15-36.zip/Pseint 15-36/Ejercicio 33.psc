Algoritmo DiaDeLaSemana
    // Definici�n de la variable correspondiente como n�mero entero
    Definir numeroDia Como Entero;
    
    // Entrada de datos del usuario
    Escribir "Ingrese un n�mero del 1 al 7:";
    Leer numeroDia;
    
    // Estructura de control para evaluar las diferentes opciones de d�as
    Segun numeroDia Hacer
        1:
            Escribir "Resultado esperado: LUNES";
        2:
            Escribir "Resultado esperado: MARTES";
        3:
            Escribir "Resultado esperado: MI�RCOLES";
        4:
            Escribir "Resultado esperado: JUEVES";
        5:
            Escribir "Resultado esperado: VIERNES";
        6:
            Escribir "Resultado esperado: S�BADO";
        7:
            Escribir "Resultado esperado: DOMINGO";
        De Otro Modo:
            // Control para cualquier otro valor fuera del rango 1-7
            Escribir "Resultado esperado: OPCI�N INV�LIDA";
    FinSegun
FinAlgoritmo
