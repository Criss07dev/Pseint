Algoritmo CategoriaDeVoto
    // Definici�n de la variable correspondiente como n�mero entero
    Definir edad Como Entero;
    
    // Entrada de datos del usuario
    Escribir "Ingresa la edad de la persona:";
    Leer edad;
    
    // Estructura condicional anidada seg�n las reglas de la tabla
    Si edad < 16 Entonces
        Escribir "Resultado: NO PUEDE VOTAR";
    Sino
        Si (edad >= 16 Y edad <= 17) O edad >= 70 Entonces
            Escribir "Resultado: VOTO OPCIONAL";
        Sino
            Escribir "Resultado: VOTO OBLIGATORIO";
        FinSi
    FinSi
FinAlgoritmo

