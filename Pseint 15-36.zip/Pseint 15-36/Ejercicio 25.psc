Algoritmo PrecioSegunFormaDePago
    // Definici�n de las variables correspondientes con sus tipos correctos
    Definir precio, valorFinal Como Real;
    Definir opcionPago Como Entero;
    
    // Entrada de datos del usuario
    Escribir "Precio: $ ";
    Leer precio;
    
    Escribir "Opci�n:";
    Leer opcionPago;
    
    // Estructura de control para evaluar las diferentes opciones de pago
    Segun opcionPago Hacer
        1:
            // 10% de descuento
            valorFinal <- precio * 0.90;
        2:
            // 5% de descuento
            valorFinal <- precio * 0.95;
        3:
            // Sin cambio
            valorFinal <- precio;
        4:
            // 8% de recargo
            valorFinal <- precio * 1.08;
        De Otro Modo:
            Escribir "Opci�n inv�lida";
            valorFinal <- precio;
    FinSegun
    
    // Mostrar el valor final en pantalla respetando el ejemplo de ejecuci�n
    Escribir "Valor final: $ ", valorFinal;
FinAlgoritmo
