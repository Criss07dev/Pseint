Algoritmo SituacionDelAlumnoPorRango
    // Definici�n de las variables correspondientes como n�meros reales
    Definir nota1, nota2, promedio Como Real;
    
    // Entrada de datos del usuario
    Escribir "Nota 1:";
    Leer nota1;
    
    Escribir "Nota 2:";
    Leer nota2;
    
    // Proceso: Calcular el promedio de las dos notas
    promedio <- (nota1 + nota2) / 2;
    
    // Mostrar el promedio obtenido en pantalla
    Escribir "Promedio: ", promedio;
    
    // Estructura condicional anidada seg�n la tabla de rangos del ejercicio
    Si promedio < 5.0 Entonces
        Escribir "Situaci�n: REPROBADO";
    Sino
        Si promedio >= 5.0 Y promedio < 7.0 Entonces
            Escribir "Situaci�n: RECUPERACI�N";
        Sino
            Escribir "Situaci�n: APROBADO";
        FinSi
    FinSi
FinAlgoritmo
