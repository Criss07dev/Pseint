Algoritmo AprobacionDePrestamo
    // Definici�n de las variables correspondientes como n�meros reales y enteros
    Definir valorInmueble, salario, cuota, limite Como Real;
    Definir plazoAnios Como Entero;
    
    // Entrada de datos del usuario
    Escribir "Valor del inmueble: $ ";
    Leer valorInmueble;
    
    Escribir "Salario: $ ";
    Leer salario;
    
    Escribir "Plazo (en a�os):";
    Leer plazoAnios;
    
    // Proceso: Calcular la cuota mensual y el l�mite del 30% del salario
    cuota <- valorInmueble / (plazoAnios * 12);
    limite <- salario * 0.30;
    
    // Mostrar el valor de la cuota y el l�mite seg�n el REQUISITO
    Escribir "Cuota: $ ", cuota;
    Escribir "L�mite: $ ", limite;
    
    // Estructura condicional para evaluar la aprobaci�n (cuando no supera el l�mite)
    Si cuota <= limite Entonces
        Escribir "Resultado: APROBADO";
    Sino
        Escribir "Resultado: RECHAZADO";
    FinSi
FinAlgoritmo

