Algoritmo ConteoDe1A10
    // Definici�n de la variable de control correspondiente como n�mero entero
    Definir i Como Entero;
    
    // Estructura de repetici�n para contar desde 1 hasta 10, uno por l�nea
    Para i <- 1 Hasta 10 Con Paso 1 Hacer
        Escribir i;
    FinPara
FinAlgoritmo
