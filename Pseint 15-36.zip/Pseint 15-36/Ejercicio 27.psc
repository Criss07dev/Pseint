Algoritmo ClasificacionIMC
    // Definici�n de las variables correspondientes como n�meros reales
    Definir peso, altura, imc Como Real;
    
    // Entrada de datos del usuario
    Escribir "Peso:";
    Leer peso;
    
    Escribir "Altura:";
    Leer altura;
    
    // Proceso: Calcular el �ndice de Masa Corporal (IMC)
    imc <- peso / (altura * altura);
    
    // Mostrar el IMC obtenido en pantalla
    Escribir "IMC: ", imc;
    
    // Estructura condicional anidada seg�n las reglas de la tabla
    Si imc < 18.5 Entonces
        Escribir "Clasificaci�n: POR DEBAJO DEL RANGO";
    Sino
        Si imc >= 18.5 Y imc < 25.0 Entonces
            Escribir "Clasificaci�n: RANGO NORMAL";
        Sino
            Si imc >= 25.0 Y imc < 30.0 Entonces
                Escribir "Clasificaci�n: POR ENCIMA DEL RANGO";
            Sino
                Escribir "Clasificaci�n: RANGO ELEVADO";
            FinSi
        FinSi
    FinSi
FinAlgoritmo
