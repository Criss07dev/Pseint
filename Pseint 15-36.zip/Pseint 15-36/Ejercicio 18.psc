Algoritmo MayorDeDosNumeros
    // Definici�n de las variables correspondientes como n�meros reales
    Definir valor1, valor2 Como Real;
    
    // Entrada de datos del usuario
    Escribir "Primer valor:";
    Leer valor1;
    
    Escribir "Segundo valor:";
    Leer valor2;
    
    // Estructura condicional para evaluar cu�l es el mayor o si son iguales
    Si valor1 > valor2 Entonces
        Escribir "Mayor valor: ", valor1;
    Sino
        Si valor2 > valor1 Entonces
            Escribir "Mayor valor: ", valor2;
        Sino
            Escribir "VALORES IGUALES";
        FinSi
    FinSi
FinAlgoritmo
