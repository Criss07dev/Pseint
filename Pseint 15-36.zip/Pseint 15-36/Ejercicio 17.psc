Algoritmo ParOImpar
    // Definici�n de la variable correspondiente como n�mero entero
    Definir num Como Entero;
    
    // Entrada de datos del usuario
    Escribir "Ingresa un n�mero:";
    Leer num;
    
    // Estructura condicional utilizando el operador MOD (resto de la divisi�n por 2)
    Si num MOD 2 == 0 Entonces
        Escribir "Resultado: PAR";
    Sino
        Escribir "Resultado: IMPAR";
    FinSi
FinAlgoritmo
