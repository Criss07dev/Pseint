Algoritmo DivisiblePor3YPor5
    // Definici�n de la variable correspondiente como n�mero entero
    Definir num Como Entero;
    
    // Entrada de datos del usuario
    Escribir "Ingrese un n�mero entero:";
    Leer num;
    
    // Estructura condicional anidada para evaluar las divisibilidades
    Si num MOD 3 = 0 Y num MOD 5 = 0 Entonces
        Escribir "Resultado esperado: DIVISIBLE POR 3 Y 5";
    Sino
        Si num MOD 3 = 0 Entonces
            Escribir "Resultado esperado: SOLO POR 3";
        Sino
            Si num MOD 5 = 0 Entonces
                Escribir "Resultado esperado: SOLO POR 5";
            Sino
                Escribir "Resultado esperado: POR NINGUNO";
            FinSi
        FinSi
    FinSi
FinAlgoritmo
