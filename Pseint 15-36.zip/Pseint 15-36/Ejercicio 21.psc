Algoritmo AprobadoOReprobado
    // Definici�n de las variables correspondientes como n�meros reales
    Definir nota1, nota2, promedio Como Real;
    
    // Entrada de datos del usuario
    Escribir "Nota 1:";
    Leer nota1;
    
    Escribir "Nota 2:";
    Leer nota2;
    
    // Proceso: Calcular el promedio de las dos notas
    promedio <- (nota1 + nota2) / 2;
    
    // Mostrar el promedio obtenido en pantalla
    Escribir "Promedio: ", promedio;
    
    // Estructura condicional seg�n la regla del ejercicio (Aprobado >= 7.0)
    Si promedio >= 7.0 Entonces
        Escribir "Situaci�n: APROBADO";
    Sino
        Escribir "Situaci�n: REPROBADO";
    FinSi
FinAlgoritmo
