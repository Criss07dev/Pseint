Algoritmo TresValoresEnOrdenAscendente
    // Definici�n de las variables correspondientes como n�meros enteros
    Definir num1, num2, num3 Como Entero;
    Definir menor, medio, mayor Como Entero;
    
    // Entrada de datos del usuario
    Escribir "Ingrese el primer n�mero:";
    Leer num1;
    
    Escribir "Ingrese el segundo n�mero:";
    Leer num2;
    
    Escribir "Ingrese el tercer n�mero:";
    Leer num3;
    
    // Estructura l�gica para comparar las 6 combinaciones posibles
    Si num1 <= num2 Y num2 <= num3 Entonces
        menor <- num1; medio <- num2; mayor <- num3;
    Sino
        Si num1 <= num3 Y num3 <= num2 Entonces
            menor <- num1; medio <- num3; mayor <- num2;
        Sino
            Si num2 <= num1 Y num1 <= num3 Entonces
                menor <- num2; medio <- num1; mayor <- num3;
            Sino
                Si num2 <= num3 Y num3 <= num1 Entonces
                    menor <- num2; medio <- num3; mayor <- num1;
                Sino
                    Si num3 <= num1 Y num1 <= num2 Entonces
                        menor <- num3; medio <- num1; mayor <- num2;
                    Sino
                        menor <- num3; medio <- num2; mayor <- num1;
                    FinSi
                FinSi
            FinSi
        FinSi
    FinSi
    
    // Mostrar el resultado final siguiendo el formato del ejemplo
    Escribir "Orden ascendente: ", menor, ", ", medio, ", ", mayor;
FinAlgoritmo


