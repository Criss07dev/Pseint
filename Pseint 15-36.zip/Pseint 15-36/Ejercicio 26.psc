Algoritmo AjustePorRangoSalarial
    // Definici�n de las variables correspondientes como n�meros reales
    Definir salarioActual, porcentaje, valorAumento, nuevoSalario Como Real;
    
    // Entrada de datos del usuario
    Escribir "Ingrese el salario actual:";
    Leer salarioActual;
    
    // Estructura condicional anidada para determinar el porcentaje seg�n la tabla
    Si salarioActual <= 1500.00 Entonces
        porcentaje <- 15;
    Sino
        Si salarioActual > 1500.00 Y salarioActual <= 3000.00 Entonces
            porcentaje <- 10;
        Sino
            porcentaje <- 5;
        FinSi
    FinSi
    
    // C�lculos matem�ticos requeridos
    valorAumento <- salarioActual * (porcentaje / 100);
    nuevoSalario <- salarioActual + valorAumento;
    
    // Mostrar los resultados en pantalla seg�n las exigencias del requisito
    Escribir "Porcentaje aplicado: ", porcentaje, "%";
    Escribir "Valor del aumento: $ ", valorAumento;
    Escribir "Nuevo salario: $ ", nuevoSalario;
FinAlgoritmo
