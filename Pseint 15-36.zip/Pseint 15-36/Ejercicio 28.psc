Algoritmo EsPosibleFormarUnTriangulo
    // Definici�n de las variables correspondientes como n�meros reales
    Definir lado1, lado2, lado3 Como Real;
    
    // Entrada de datos del usuario
    Escribir "Lado 1:";
    Leer lado1;
    
    Escribir "Lado 2:";
    Leer lado2;
    
    Escribir "Lado 3:";
    Leer lado3;
    
    // Estructura condicional que eval�a si cada lado es menor que la suma de los otros dos
    Si (lado1 < lado2 + lado3) Y (lado2 < lado1 + lado3) Y (lado3 < lado1 + lado2) Entonces
        Escribir "Resultado: FORMAN UN TRI�NGULO";
    Sino
        Escribir "Resultado: NO FORMAN";
    FinSi
FinAlgoritmo
