Algoritmo TipoDeTriangulo
    // Definici�n de las variables correspondientes como n�meros reales
    Definir lado1, lado2, lado3 Como Real;
    
    // Entrada de datos del usuario
    Escribir "Lado 1:";
    Leer lado1;
    
    Escribir "Lado 2:";
    Leer lado2;
    
    Escribir "Lado 3:";
    Leer lado3;
    
    // Primero, verificar si las tres medidas pueden formar un tri�ngulo
    Si (lado1 < lado2 + lado3) Y (lado2 < lado1 + lado3) Y (lado3 < lado1 + lado2) Entonces
        
        // Si lo forman, se clasifica seg�n la igualdad de sus lados
        Si lado1 == lado2 Y lado2 == lado3 Entonces
            Escribir "Resultado esperado: EQUIL�TERO";
        Sino
            Si lado1 == lado2 O lado1 == lado3 O lado2 == lado3 Entonces
                Escribir "Resultado esperado: IS�SCELES";
            Sino
                Escribir "Resultado esperado: ESCALENO";
            FinSi
        FinSi
        
    Sino
        // Si no cumple la regla de existencia del tri�ngulo
        Escribir "Resultado esperado: NO FORMA TRI�NGULO";
    FinSi
FinAlgoritmo
