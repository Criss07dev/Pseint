Algoritmo NumeroDentroDelIntervalo
    // Definici�n de la variable correspondiente como n�mero real
    Definir num Como Real;
    
    // Entrada de datos del usuario
    Escribir "Ingrese un n�mero real:";
    Leer num;
    
    // Estructura condicional para evaluar el intervalo cerrado de 10 a 20
    Si num >= 10 Y num <= 20 Entonces
        Escribir "Resultado esperado: DENTRO";
    Sino
        Escribir "Resultado esperado: FUERA";
    FinSi
FinAlgoritmo
