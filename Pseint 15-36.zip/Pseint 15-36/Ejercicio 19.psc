Algoritmo MayorYMenorDeTresNumeros
    // Definici�n de las variables correspondientes como n�meros reales
    Definir num1, num2, num3 Como Real;
    Definir mayor, menor Como Real;
    
    // Entrada de datos
    Escribir "Ingrese el primer n�mero:";
    Leer num1;
    
    Escribir "Ingrese el segundo n�mero:";
    Leer num2;
    
    Escribir "Ingrese el tercer n�mero:";
    Leer num3;
    
    // L�gica para encontrar el n�mero MAYOR
    Si num1 >= num2 Y num1 >= num3 Entonces
        mayor <- num1;
    Sino
        Si num2 >= num1 Y num2 >= num3 Entonces
            mayor <- num2;
        Sino
            mayor <- num3;
        FinSi
    FinSi
    
    // L�gica para encontrar el n�mero MENOR
    Si num1 <= num2 Y num1 <= num3 Entonces
        menor <- num1;
    Sino
        Si num2 <= num1 Y num2 <= num3 Entonces
            menor <- num2;
        Sino
            menor <- num3;
        FinSi
    FinSi
    
    // Mostrar resultados en pantalla seg�n el ejemplo de ejecuci�n
    Escribir "Mayor: ", mayor;
    Escribir "Menor: ", menor;
FinAlgoritmo

