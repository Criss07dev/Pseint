Algoritmo ValorDeLaEntrada
    // Definici�n de las variables correspondientes con sus tipos correctos
    Definir edad Como Entero;
    Definir esEstudiante Como Caracter;
    Definir valorFinal Como Real;
    
    // Entrada de datos del usuario
    Escribir "Edad:";
    Leer edad;
    
    Escribir "Estudiante (S�/NO):";
    Leer esEstudiante;
    
    // Estructura condicional aplicando la regla de descuento (no acumulativo)
    Si edad < 12 O esEstudiante = "S�" O esEstudiante = "SI" O edad >= 60 Entonces
        // Aplica el 50% de descuento sobre los $ 30.00
        valorFinal <- 30.00 * 0.50;
    Sino
        // Paga el precio completo
        valorFinal <- 30.00;
    FinSi
    
    // Mostrar el resultado final en pantalla respetando el formato del ejemplo
    Escribir "Valor de la entrada: $ ", valorFinal;
FinAlgoritmo
